package com.example.springjpahibernatemysql.security;

public class SecurityConfig {

}
