package com.example.springjpahibernatemysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaHibernateMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
